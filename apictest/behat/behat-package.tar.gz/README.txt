This is a zipped up copy of drupal-extension after it has been `npm installed`.
We need this for our production container images which don't have npm, make, python
and a bunch of other utilities. In a production container, we can extract this
archive in the correct directory and run our tests normally after that.

This file was created by : 

 1. downloading a platform and site template file from the latest apimprofile build / artifactory
 2. extracting the platform to a linux machine
 3. running `setupbehat.sh https://ibm.com/example TRUE`
 4. Grabbing the behat and drupal directories from apictest/../../vendor/
