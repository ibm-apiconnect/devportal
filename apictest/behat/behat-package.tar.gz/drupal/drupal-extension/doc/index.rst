.. the Drupal Extension to Behat and Mink documentation master file, created by
   sphinx-quickstart on Sun Jul  7 09:40:13 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the Drupal Extension to Behat and Mink's documentation!
==================================================================

Contents:

.. toctree::
   :maxdepth: 1 

   intro
   requirements
   localinstall
   globalinstall
   environment
   drivers
   blackbox
   drush
   drupalapi
   contexts
   subcontexts
